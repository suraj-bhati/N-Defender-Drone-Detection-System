#!/usr/bin/env bash
set -euo pipefail
echo "[+] Setting up N-Defender backend..."
python3 -m venv .venv
source .venv/bin/activate
pip install -r software/backend/requirements.txt
echo "[+] Done. Run with: uvicorn software/backend/app:app --reload --port 8080"
