# N-Defender Drone Detection System

A 7″ touchscreen **drone detection & localization** platform covering ~**1 MHz–6 GHz**, with:
- Wideband SDR scanning
- Sub‑GHz coherent **direction finding (DF)** & triangulation
- **2.4 / 5.8 GHz** presence + bearing via RSSI heads
- **Analog 5.8 GHz FPV** video reception
- **Remote ID** (BLE/Wi‑Fi) decoding & mapping
- Beautiful, touch‑friendly UI with map, spectrum, targets & live stats

> **Status:** pre‑alpha • **License:** MIT • **Owner:** AnuShakti Infotech Pvt. Ltd. (FlySpark)

## Monorepo Layout
```
/docs/                — Specs, diagrams, API, ops
/hardware/            — Antennas, LNAs, filters, enclosures, BoM
/firmware/            — MCU (RSSI head, pan/tilt), DF helpers
/software/
  backend/            — API gateway (FastAPI), device managers
  processing/         — SDR/DF pipelines, detectors, triangulation
  ui/                 — Touch UI (web), mockups, assets
/tests/               — Unit/integration tests
/scripts/             — Setup, dev tools, helpers
.github/              — CI, issue templates
```

## Quick Start (developer)
```bash
# 1) Create venv & install backend deps
cd software/backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

# 2) Run API locally
uvicorn app:app --reload --port 8080

# 3) Open UI mock (static)
# (Open software/ui/mockup/index.html in a browser for now)
```

## Planned Major Components
- **DF Engine:** Kraken‑class coherent SDR server (sub‑GHz AoA) with WebSocket output
- **Wideband Scan:** HackRF/USRP via GNU Radio/Soapy
- **RSSI Heads:** AD8318 + MCU streaming serial metrics
- **RID:** OpenDroneID receiver service
- **UI:** Leaflet map, spectrum/waterfall, targets list, analog video pane

See `/docs/ProjectSpec.md` for full requirements & milestones.
