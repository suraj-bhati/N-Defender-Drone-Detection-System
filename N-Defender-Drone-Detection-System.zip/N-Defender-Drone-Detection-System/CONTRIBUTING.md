# Contributing Guidelines

1. Use feature branches; open PRs to `main`.
2. Keep commits small and descriptive.
3. Write docs/tests for new features.
4. Follow repo layout and naming conventions.
