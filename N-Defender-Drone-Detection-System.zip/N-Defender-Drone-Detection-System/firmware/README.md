# Firmware (MCU) — RSSI head & pan/tilt (placeholder)
# - Read AD8318 analog RSSI via ADC
# - Stream over UART @ 115200: JSON lines {band, rssi_dbm, ts}
# - Control pan/tilt servos to sweep and auto‑peak direction
