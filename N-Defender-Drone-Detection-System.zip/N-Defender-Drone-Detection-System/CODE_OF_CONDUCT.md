# Code of Conduct

Be respectful. No harassment or discrimination. Collaborate constructively. Report issues to maintainers.
