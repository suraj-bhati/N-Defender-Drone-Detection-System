# API Overview (internal)

## REST / WebSocket
- `GET /health` — service status
- `GET /api/targets` — list active detections
- `POST /api/bearings` — submit remote-node bearing for fusion
- `GET /api/logs` — recent events (paginated)
- WebSocket `/ws` — live events stream (targets, spectrum peaks, DF bearings)
