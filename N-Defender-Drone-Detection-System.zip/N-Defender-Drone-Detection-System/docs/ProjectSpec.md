# Project Specification — N-Defender Drone Detection System

**Goal:** Field‑deployable detector & locator with 7″ touch UI, ~1 MHz–6 GHz coverage, analog FPV, DF & triangulation, Remote ID display.

## Capabilities (v1)
- Wideband spectrum survey & focused monitoring
- Sub‑GHz coherent DF bearings (≤±10° RMS with good geometry)
- Multi‑node triangulation (bearing fusion)
- 2.4/5.8 GHz presence + bearing (RSSI + directional antenna)
- 5.8 GHz analog FPV video window & recording (where lawful)
- Remote ID (BLE/Wi‑Fi) decode & map overlay
- Logs + CSV/KML/GeoJSON export; day/night UI

## Hardware Blocks
- Compute/UI: Raspberry Pi 4/5 + 7″ capacitive touch
- SDRs: HackRF (value) or USRP B200mini (pro); coherent DF engine (Kraken‑class)
- High‑gain antennas per band; LNAs + SAW/BPF filters near feed
- RSSI heads (AD8318) + MCU; optional pan/tilt
- GNSS + IMU; rugged power & enclosure

## Software Blocks
- Backend API (FastAPI), device managers, WebSocket event bus
- Processing pipelines (GNU Radio/Soapy), DF client, RID receiver
- UI (web): map (Leaflet), spectrum, targets, video, settings, logs
- Storage: SQLite + exporters

## Milestones
- M1: UI skeleton + spectrum survey + analog video
- M2: Sub‑GHz DF online + drive‑around solve
- M3: High‑band bearing (RSSI) + pan/tilt
- M4: RID overlay + multi‑node fusion
- M5: Field validation & v1 release
