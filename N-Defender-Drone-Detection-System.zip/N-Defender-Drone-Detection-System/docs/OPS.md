# Operations Guide (draft)

- Power sequencing, thermal notes
- Antenna placement & calibration
- DF array calibration (compass, spacing, phase)
- Field test checklist & acceptance criteria
