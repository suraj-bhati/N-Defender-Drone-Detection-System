# Placeholder for SDR/DF processing pipelines
# - GNU Radio / Soapy blocks
# - Spectrum scanning + peak picking
# - DF client (reads bearings from coherent DF server)
# - RID receiver adaptor
