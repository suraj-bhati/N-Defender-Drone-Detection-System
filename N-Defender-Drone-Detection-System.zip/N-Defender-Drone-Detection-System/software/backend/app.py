from fastapi import FastAPI, WebSocket
from pydantic import BaseModel
from typing import List, Optional
import time

app = FastAPI(title="N-Defender Backend", version="0.1.0")

class Bearing(BaseModel):
    node_id: str
    lat: float
    lon: float
    heading: float
    bearing: float
    sigma: float = 10.0
    t: Optional[float] = None

class Target(BaseModel):
    id: str
    freq_hz: float
    band: str
    rssi_dbm: float
    bearing_deg: Optional[float] = None
    type: str = "unknown"  # analog, digital, rid, unknown
    last_seen: float = time.time()

# In-memory demo data
TARGETS: List[Target] = []

@app.get("/health")
def health():
    return {"status": "ok", "time": time.time()}

@app.get("/api/targets", response_model=List[Target])
def list_targets():
    return TARGETS

@app.post("/api/bearings")
def submit_bearing(b: Bearing):
    # TODO: fuse bearings into a location estimate
    return {"ok": True, "received": b.dict()}

@app.websocket("/ws")
async def ws_endpoint(ws: WebSocket):
    await ws.accept()
    await ws.send_json({"type": "hello", "service": "n-defender", "time": time.time()})
    # Demo: no push loop here; processing service should push events.
    await ws.close()
