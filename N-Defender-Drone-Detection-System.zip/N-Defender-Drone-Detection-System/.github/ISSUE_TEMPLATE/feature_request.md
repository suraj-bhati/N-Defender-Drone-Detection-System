---
name: Feature request
about: Suggest an idea for this project
title: "[FEAT] <short summary>"
labels: enhancement
assignees: ''
---

**Problem statement**

**Proposed solution**

**Alternatives considered**

**Additional context**
